package tenant

import (
	"fmt"
	"github.com/google/uuid"
	consul "github.com/hashicorp/consul/api"
	"gitlab.sessionm.com/xymon/xy/util"
	"golang.org/x/crypto/ssh"
	yaml "gopkg.in/yaml.v2"
	"strings"
)

type Tenant struct {
	SshClient        *ssh.Client
	TenantName       string
	DatabaseYml      string
	SystemYml        string
	EnvironmentLevel string
}

type Db struct {
	Production struct {
		Database string
		Host     string
		Username string
		Password string
	}
	Read_slave struct {
		Host string
	}
}

type Rs struct {
	Id               int
	Config           string
	Name             string
	Domains          []string
	environmentLevel string
}

type ServiceURL struct {
	URL string `yaml:"url"`
}

type RewardsSystems struct {
	Rewards_systems map[string]*Rs
}

type BaseConfig struct {
	WhiteLabelApp      bool           `yaml:"white_label"`
	RewardsSystems     map[string]*Rs `yaml:"rewards_systems"`
	RewardsSystemsByID map[int]*Rs
	Services           map[string]*ServiceURL
}

type NewTenant func(envLevel string, tenantName string, client *ssh.Client) *Tenant

func Cache() NewTenant {
	// map[stg][economy] would return an instance of the organization struct
	var tenantStore = map[string]map[string]Tenant{
		"ent":      {},
		"ent_ca":   {},
		"ent_ie":   {},
		"ent_sg":   {},
		"ent_west": {},
		"q":        {},
		"stg":      {},
		"stg_ca":   {},
	}

	return func(envLevel string, tenantName string, client *ssh.Client) *Tenant {
		if res, ok := tenantStore[envLevel][tenantName]; ok {
			return &res
		} else {
			tn := Tenant{
				client,
				tenantName,
				util.ExecuteCmd(fmt.Sprintf("cat %s", databaseYmlPath(tenantName)), client),
				util.ExecuteCmd(fmt.Sprintf("cat %s", systemYmlPath(tenantName)), client),
				envLevel,
			}
			tenantStore[envLevel][tenantName] = tn
			return &tn
		}
	}
}

func (tn Tenant) Database() *Db {
	dbinfo := Db{}
	ymlerr := yaml.Unmarshal([]byte(tn.DatabaseYml), &dbinfo)
	if ymlerr != nil {
		panic("Yaml error in database.yml; This is not good.")
	}
	return &dbinfo
}

func (tn Tenant) GetRewardsSystemsByID(rewardsSystems map[string]*Rs) map[int]*Rs {
	rsById := make(map[int]*Rs)

	for k, v := range rewardsSystems {
		if k == "default" {
			// config is the system.yml file where everything lives.
			// blick_staging_system.yml
			names := strings.Split(v.Config, "_")
			v.Name = names[0]
		} else {
			v.Name = k
		}
		v.environmentLevel = tn.EnvironmentLevel
		rsById[v.Id] = v
	}
	return rsById
}

func (tn Tenant) LoginRewardsSystemsAndDomainsAreConfigured() bool {
	rsinfo := RewardsSystems{}
	systemYml := util.ExecuteCmd(fmt.Sprintf("cat %s", systemYmlLoginPath(tn.TenantName)), tn.SshClient)
	ymlerr := yaml.Unmarshal([]byte(systemYml), &rsinfo)
	if ymlerr != nil {
		panic("Yaml error in rewards_systems.yml; This is not good.")
	}

	for _, v := range rsinfo.Rewards_systems {
		if v.Id == 0 {
			return false
		} else if len(v.Domains) == 0 {
			return false
		}
	}
	return true
}

func (tn Tenant) GetBaseConfig() (*BaseConfig, error) {
	var baseConfig BaseConfig
	systemYml := util.ExecuteCmd(fmt.Sprintf("cat %s", systemYmlPath(tn.TenantName)), tn.SshClient)
	err := yaml.Unmarshal([]byte(systemYml), &baseConfig)
	if err != nil {
		return &baseConfig, err
	}

	baseConfig.RewardsSystemsByID = tn.GetRewardsSystemsByID(baseConfig.RewardsSystems)

	return &baseConfig, nil
}

func (tn Tenant) ConsulUrl() string {
	return fmt.Sprintf("https://consul.%s.local", strings.Replace(tn.EnvironmentLevel, "_", "-", 1))
}

func (tn Tenant) ConsulClient() *consul.Client {
	config := consul.DefaultConfig()
	config.Address = tn.ConsulUrl()
	config.TLSConfig.InsecureSkipVerify = true
	client, err := consul.NewClient(config)

	if err != nil {
		panic(err)
	}
	return client
}

func (tn Tenant) EnvironmentDnsLevel() string {
	dns := ""
	if strings.Contains(tn.EnvironmentLevel, "ent") {
		dns = "ent"
	} else if strings.Contains(tn.EnvironmentLevel, "stg") {
		dns = "stg"
	} else {
		dns = "q"
	}

	return dns
}

func (tn Tenant) ExecuteSqlCmd(sqlstring string) string {
	file := uuid.New()
	util.ExecuteCmd(fmt.Sprintf("install -m 666 /dev/null /tmp/xy/%s/%s.xy", tn.TenantName, file), tn.SshClient)
	util.ExecuteCmd(fmt.Sprintf("mysql -B -u %s -p%s -h %s %s -e \" %s \" > /tmp/xy/%s/%s.xy", tn.Database().Production.Username, tn.Database().Production.Password, tn.Database().Production.Host, tn.Database().Production.Database, sqlstring, tn.TenantName, file), tn.SshClient)
	sqlResult := util.ExecuteCmd(fmt.Sprintf("cat /tmp/xy/%s/%s.xy", tn.TenantName, file), tn.SshClient)
	util.ExecuteCmd(fmt.Sprintf("rm /tmp/xy/%s/%s.xy", tn.TenantName, file), tn.SshClient)
	return sqlResult
}

func (tn Tenant) SqlNumberResult(sqlResultString string) string {
	sqlArr := strings.Split(sqlResultString, "\n")
	sqlArrNonEmpty := []string{}
	for _, str := range sqlArr {
		if str != "" {
			sqlArrNonEmpty = append(sqlArrNonEmpty, str)
		}
	}
	if len(sqlArrNonEmpty) == 0 {
		return "0"
	}
	result := sqlArrNonEmpty[len(sqlArrNonEmpty)-1]
	return result
}

// all sorts of fucked up system.ymls
func (rs *Rs) CoreUrl(organizationName string) string {
	for _, domain := range rs.Domains {
		if strings.HasPrefix(domain, "-") {
			return fmt.Sprintf("https://api%s", domain)
		}

		if strings.Contains(domain, "api") {
			if strings.Contains(domain, "http") {
				return domain
			} else {
				return fmt.Sprintf("https://%s", domain)
			}
		}
	}

	dns := ""
	if strings.Contains(rs.environmentLevel, "ent") {
		dns = "ent"
	} else if strings.Contains(rs.environmentLevel, "stg") {
		dns = "stg"
	} else {
		dns = "q"
	}
	return fmt.Sprintf("https://api-%s.%s-sessionm.com/", strings.ToLower(strings.Replace(organizationName, " ", "-", 1)), dns)
}

func (rs *Rs) LoginUrl(organizationName string) string {
	return strings.Replace(rs.CoreUrl(organizationName), "api", "login", 1)
}

func (rs *Rs) OndemandUrl(organizationName string) string {
	return strings.Replace(rs.CoreUrl(organizationName), "api", "mmc", 1)
}

func (rs *Rs) TenantUrlName(organizationName string) string {
	coreUrl := rs.CoreUrl(organizationName)
	cleansed := strings.Replace(coreUrl, "https://api-", "", 1)
	split := strings.Split(cleansed, ".")
	return split[0]
}

func databaseYmlPath(tenantName string) string {
	return fmt.Sprintf("/product/voltron/%s/data/globals/config/database.yml", tenantName)
}

func systemYmlPath(tenantName string) string {
	return fmt.Sprintf("/product/voltron/%s/data/core/shared/config/system.yml", tenantName)
}

func systemYmlLoginPath(tenantName string) string {
	return fmt.Sprintf("/product/voltron/%s/data/login/shared/config/system.yml", tenantName)
}
