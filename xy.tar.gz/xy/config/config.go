package config

import (
	"bufio"
	"encoding/json"
	"fmt"
	"github.com/spf13/viper"
	"go.uber.org/zap"
	"os"
	"os/user"
	"reflect"
	"strconv"
	"strings"
	"text/tabwriter"
	"time"
)

const (
	XyConfigFile = ".xy"
	XymonUrl     = "http://xymon.infra.local/hosts.json"
)

func SshUser() string {
	user, _ := user.Current()
	return user.Username
}

func HomePath() string {
	user, _ := user.Current()
	return user.HomeDir
}

func EnsurePathExists(path string) error {
	// mkdir ensures that the path exists, or else creates.
	err := os.MkdirAll(fmt.Sprintf("%s", path), os.FileMode(int(0777)))
	return err
}

func ReadXyConfig() (*viper.Viper, error) {
	return ReadConfig(XyConfigFile, map[string]interface{}{
		"username":            SshUser(),
		"xymon_url":           XymonUrl,
		"postman_export_path": fmt.Sprintf("%s/xypostman", HomePath()), // folder might not actually exist; we don't want to actually create the folder yet, so we don't spam stuff we don't need
	})
}

func ReadConfig(filename string, defaults map[string]interface{}) (*viper.Viper, error) {
	v := viper.New()
	_, err := os.Stat(fmt.Sprintf("%s/%s.yaml", HomePath(), filename))

	if err == nil {
		v.AddConfigPath(HomePath())
		v.SetConfigName(filename)
		readerr := v.ReadInConfig()
		if readerr != nil {
			switch err.(type) {
			case viper.ConfigFileNotFoundError:
			default:
				fmt.Println(fmt.Sprintf("Error Reading Config File:  %s", reflect.TypeOf(err)))
			}
		}
		return v, readerr
	}
	for key, value := range defaults {
		v.SetDefault(key, value)
	}
	return v, err
}

func HistoryLogger() *zap.SugaredLogger {
	rawJSON := []byte(fmt.Sprintf(`{
	  "level": "info",
	  "encoding": "json",
	  "outputPaths": ["%s"],
	  "errorOutputPaths": [],
	  "encoderConfig": {
	    "messageKey": "message",
	    "levelKey": "level",
	    "levelEncoder": "lowercase"
	  }
	}`, logFileLocation()))

	var cfg zap.Config
	if err := json.Unmarshal(rawJSON, &cfg); err != nil {
		panic(err)
	}
	logger, zaperr := cfg.Build()
	if zaperr != nil {
		panic(zaperr)
	}
	defer logger.Sync() // flushes buffer, if any

	sugar := logger.Sugar()
	return sugar
}

type LogEntry struct {
	Command string `json:command`
}

type Root struct {
	Level     string   `json:level`
	Message   string   `json:message`
	Command   string   `json:command`
	Ipaddress string   `json:ipaddress`
	Time      jsonTime `json:timestamp`
}

type jsonTime time.Time

func (t jsonTime) MarshalJSON() ([]byte, error) {
	return []byte(strconv.FormatInt(time.Time(t).Unix(), 10)), nil
}

func (t *jsonTime) UnmarshalJSON(s []byte) (err error) {
	r := strings.Replace(string(s), `"`, ``, -1)

	q, err := strconv.ParseInt(r, 10, 64)
	if err != nil {
		return err
	}
	*(*time.Time)(t) = time.Unix(q, 0)
	return
}

func (t jsonTime) String() string { return time.Time(t).String() }

func ReadHistory() error {
	logFile, err := os.Open(logFileLocation())

	if err != nil {
		return err
	}

	defer logFile.Close()

	// buf := make([]byte, 62)
	// stat, err := os.Stat(logFileLocation())
	// start := stat.Size() - 62
	// _, err = logFile.ReadAt(buf, start)
	// if err == nil {
	// 	fmt.Printf("%s\n", buf)
	// }

	s := bufio.NewScanner(logFile)
	w := &tabwriter.Writer{}
	w.Init(os.Stdout, 0, 8, 2, '\t', 0)
	for s.Scan() {
		var result LogEntry
		if err := json.Unmarshal(s.Bytes(), &result); err != nil {
			//handle error
		}
		switch result.Command {
		case "root":

			var e Root
			if err := json.Unmarshal(s.Bytes(), &e); err != nil {
				panic(err)
			}
			fmt.Fprintln(w, e.Ipaddress, "\t", e.Message, "\t", e.Time)
		default:
			// ("bad message type")
		}
	}
	if s.Err() != nil {
		// handle scan error
	}
	w.Flush()
	return nil
}

func logFileLocation() string {
	return fmt.Sprintf("%s/.xy.log", HomePath())
}
