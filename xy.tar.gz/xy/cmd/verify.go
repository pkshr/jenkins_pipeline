package cmd

import (
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	. "github.com/logrusorgru/aurora"
	"github.com/olekukonko/tablewriter"
	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/verification"
	_ "gitlab.sessionm.com/xymon/xy/verification/services"
	"gitlab.sessionm.com/xymon/xy/xymon"
)

func init() {
	rootCmd.AddCommand(verifyCommand)
}

var verifyCommand = &cobra.Command{
	Use:   "verify",
	Short: "Verify services and features in an environment",
	Run: func(cmd *cobra.Command, args []string) {
		var fzfCommand string
		if len(first) > 0 {
			fzfCommand = fmt.Sprintf("fzf --no-sort -f '%s'", first)
		} else {
			fzfCommand = "fzf -m -select-1"
		}

		xy := xymon.GetXymonData()
		servers := util.FetchEligibleServers(xy, fzf.PrinterConfig{
			EnvironmentLevel:      true,
			TenantName:            true,
			HostType:              false,
			IpAddr:                false,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		}, fzfCommand)

		newTenant := tenant.Cache()
		for _, tenant := range servers {
			if len(tenant) == 0 {
				continue
			}

			info := fzf.ParseIntoXymonSelection(xy, tenant)

			voltronHost, err := info.VoltronHost()
			if err != nil {
				continue
			}

			client := util.GetSSHClient(info.JumpHost(), voltronHost)
			tn := newTenant(info.EnvironmentLevel, info.TenantName, client)
			util.ExecuteCmd(fmt.Sprintf("mkdir -m 0777 -p /tmp/xy/ && mkdir -m 0777 -p /tmp/xy/%s", info.TenantName), client)

			orgSqlStatement := "select o.id, o.name from organizations o inner join developers d on o.developer_id = d.id inner join applications a on a.developer_id = d.id where a.name = 'QA Integration Test';"
			util.ExecuteCmd(fmt.Sprintf("install -m 666 /dev/null /tmp/xy/%s/org.xy", info.TenantName), client)
			util.ExecuteCmd(fmt.Sprintf("mysql -B -u %s -p%s -h %s %s -e \" %s \" > /tmp/xy/%s/org.xy", tn.Database().Production.Username, tn.Database().Production.Password, tn.Database().Production.Host, tn.Database().Production.Database, orgSqlStatement, info.TenantName), client)
			orgInfo := util.ExecuteCmd(fmt.Sprintf("cat /tmp/xy/%s/org.xy", info.TenantName), client)
			defer util.ExecuteCmd(fmt.Sprintf("rm /tmp/xy/%s/org.xy", info.TenantName), client)
			if len(strings.Split(orgInfo, "\n")) == 0 {
				panic("Couldn't find any organizations with 'QA Integration Test' applications")
			}
			orgSelections := util.WithFilter(fzfCommand, func(in io.WriteCloser) {
				orgSlice := strings.Split(orgInfo, "\n")
				for index, credentials := range orgSlice {
					if index != 0 {
						fmt.Fprintln(in, credentials)
					}
				}
			})

			parsedOrg := parseOrganizationsSqlResult(orgSelections[0])
			apiSqlStatement := fmt.Sprintf("select o.id, o.name, a.name, a.platform, a.api_key, a.secret, d.rewards_system_id from applications a inner join developers d on d.id = a.developer_id inner join organizations o on o.developer_id = d.id where a.mode = 'live' and o.id = %d;", parsedOrg.OrganizationId)
			util.ExecuteCmd(fmt.Sprintf("install -m 666 /dev/null /tmp/xy/%s/qatest.xy", info.TenantName), client)
			util.ExecuteCmd(fmt.Sprintf("mysql -B -u %s -p%s -h %s %s -e \" %s \" > /tmp/xy/%s/qatest.xy", tn.Database().Production.Username, tn.Database().Production.Password, tn.Database().Production.Host, tn.Database().Production.Database, apiSqlStatement, info.TenantName), client)
			apiInfo := util.ExecuteCmd(fmt.Sprintf("cat /tmp/xy/%s/qatest.xy", info.TenantName), client)
			defer util.ExecuteCmd(fmt.Sprintf("rm /tmp/xy/%s/qatest.xy", info.TenantName), client)
			var qaTestOrg util.Organization
			for _, sqlLine := range strings.Split(apiInfo, "\n") {
				if len(sqlLine) == 0 {
					continue
				}
				orgResult := parseApiSqlResult(sqlLine)

				if orgResult.ApplicationName == "QA Integration Test" {
					qaTestOrg = orgResult
					break
				}
			}

			if qaTestOrg == (util.Organization{}) {
				panic("Couldn't Find 'QA Integration Test' application")
			}
			baseConfig, _ := tn.GetBaseConfig()
			rewardsSystems := baseConfig.RewardsSystemsByID
			rs := rewardsSystems[qaTestOrg.RewardsSystemId]
			services := verification.CheckServices(tn, &qaTestOrg, rs)
			table := tablewriter.NewWriter(os.Stdout)
			table.SetHeader([]string{"Service", "Feature", "Status", "Details"})
			table.SetColMinWidth(3, 100)
			table.SetAutoWrapText(false)
			// service checks
			for _, service := range services {
				var row []string
				row = append(row, service.Name, "")
				if service.ServiceCheckStatus == 0 {
					row = append(row, fmt.Sprintf("%s", Colorize(service.GetStatus(), RedBg|BoldFm)))
				} else if service.ServiceCheckStatus == 1 {
					row = append(row, fmt.Sprintf("%s", Colorize(service.GetStatus(), WhiteFg|GreenBg|BoldFm)))
				} else if service.ServiceCheckStatus == 2 {
					row = append(row, fmt.Sprintf("%s", Colorize(service.GetStatus(), BrownBg|BoldFm)))
				}
				table.Append(append(row, service.Details))

				// feature checks
				for _, feat := range service.FeatureChecks {
					var innerRow []string
					innerRow = append(innerRow, "", feat.Name)
					if feat.FeatureCheckStatus == 0 {
						innerRow = append(innerRow, fmt.Sprintf("%s", Colorize(feat.GetStatus(), RedBg|BoldFm)))
					} else if feat.FeatureCheckStatus == 1 {
						innerRow = append(innerRow, fmt.Sprintf("%s", Colorize(feat.GetStatus(), WhiteFg|GreenBg|BoldFm)))
					} else if feat.FeatureCheckStatus == 2 {
						innerRow = append(innerRow, fmt.Sprintf("%s", Colorize(feat.GetStatus(), BrownBg|BoldFm)))
					}
					table.Append(append(innerRow, feat.Details))

				}

			}
			table.Render()
		}
	},
}

func parseOrganizationsSqlResult(tabDelimitedResult string) util.Organization {
	attrs := strings.Split(tabDelimitedResult, "\t")
	organizationID, _ := strconv.Atoi(attrs[0])
	organizationName := attrs[1]
	return util.Organization{
		OrganizationId:   organizationID,
		OrganizationName: organizationName,
	}
}

func parseApiSqlResult(tabDelimitedResult string) util.Organization {
	attrs := strings.Split(tabDelimitedResult, "\t")
	organization_id, _ := strconv.Atoi(attrs[0])
	rewards_system_id, _ := strconv.Atoi(attrs[6])

	return util.Organization{
		organization_id,
		attrs[1],
		attrs[2],
		attrs[3],
		attrs[4],
		attrs[5],
		rewards_system_id,
	}
}
