package cmd

import (
	b64 "encoding/base64"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"github.com/pkg/browser"
	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/xymon"
	"golang.org/x/crypto/ssh"
	"io"
	"strconv"
	"strings"
	"time"
)

func init() {
	rootCmd.AddCommand(loginCmd)
}

var loginCmd = &cobra.Command{
	Use:   "login",
	Short: "Logs you into the mmc",
	Long:  `Creates a one ttime access token with your sessionm account on the selected env`,
	Run: func(cmd *cobra.Command, args []string) {
		fzfCommand := "fzf"

		xy := xymon.GetXymonData()

		servers := util.FetchEligibleServers(xy, fzf.PrinterConfig{
			EnvironmentLevel:      true,
			TenantName:            true,
			HostType:              false,
			IpAddr:                false,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		}, fzfCommand)

		//Get env selection. Rreturns XymonSelection
		info := fzf.ParseIntoXymonSelection(xy, servers[0])

		err := util.EnsureAgentHasKeys(util.SSHAgent())
		if err != nil {
			panic(err)
		}

		voltronHost, err := info.VoltronHost()
		if err != nil {
			panic(err)
		}

		client := util.GetSSHClient(info.JumpHost(), voltronHost)
		newTenant := tenant.Cache()
		tn := newTenant(info.EnvironmentLevel, info.TenantName, client)

		// Get organizations
		orgSqlStatement := "select id, name from organizations;"
		orgInfo := tn.ExecuteSqlCmd(orgSqlStatement)

		// Select org if more then one
		orgSelections := util.WithFilter(fzfCommand, func(in io.WriteCloser) {
			orgSlice := strings.Split(orgInfo, "\n")
			for index, credentials := range orgSlice {
				if index != 0 {
					fmt.Fprintln(in, credentials)
				}
			}
		})
		parsedOrg := parseOrganizationsSqlResult(orgSelections[0])

		//Get Encyption key
		rewardsSystemQuery := fmt.Sprintf("select rs.encryption_key, rs.id from organizations o "+
			"inner join developers d on o.developer_id = d.id "+
			"inner join rewards_systems rs on d.rewards_system_id = rs.id "+
			"where o.id = %d;", parsedOrg.OrganizationId)
		rewardsSystemQueryResult := tn.ExecuteSqlCmd(rewardsSystemQuery)

		// See if user has an account
		rewardsSystemParsedResults := strings.Split(strings.Split(rewardsSystemQueryResult, "\n")[1], "\t")
		rewardsSystemId, _ := strconv.Atoi(rewardsSystemParsedResults[1])
		encryptionKey, err := b64.StdEncoding.DecodeString(rewardsSystemParsedResults[0])
		encryptedEmail := util.EncryptUniqueString(fmt.Sprintf("%s@sessionm.com", util.SshUser()), encryptionKey)
		accountId, err := LookupAccountId(encryptedEmail, tn, client, info)

		// User does not have an account
		currentTime := time.Now().In(time.UTC)
		if err != nil {
			firstName := string(util.SshUser()[0])
			lastName := string(util.SshUser()[1:])
			createAccountQuery := fmt.Sprintf("insert into accounts (first_name, last_name, organization_id, email_encrypted, confirmed_at) values ('%s', '%s', %d, '%s', '%s');", firstName, lastName, parsedOrg.OrganizationId, encryptedEmail, currentTime)
			tn.ExecuteSqlCmd(createAccountQuery)
			accountId, _ = LookupAccountId(encryptedEmail, tn, client, info)
		}
		AssignPermissions(accountId, tn, client, info, parsedOrg)

		// Generate token and create record
		token := uuid.New()
		tokenExpirsAt := currentTime.Add(time.Minute * 5) // Token lasts for 5 minutes
		tokenQuery := fmt.Sprintf("insert into account_login_tokens (account_id, token, expires_at, active, created_at, updated_at) values (%d, '%s', '%s', %d, '%s', '%s') ;", accountId, token, tokenExpirsAt.Format(time.RFC3339), 1, currentTime.Format(time.RFC3339), currentTime.Format(time.RFC3339))
		tn.ExecuteSqlCmd(tokenQuery)

		// Generate login URL
		baseConfig, _ := tn.GetBaseConfig()
		rewardsSystems := baseConfig.RewardsSystemsByID
		rs := rewardsSystems[rewardsSystemId]
		loginURL := fmt.Sprintf("%s/account/login/%s", rs.OndemandUrl(parsedOrg.OrganizationName), token)
		browser.OpenURL(loginURL)
	},
}

func LookupAccountId(email string, tn *tenant.Tenant, client *ssh.Client, info xymon.XymonSelection) (int, error) {
	emailQuery := fmt.Sprintf("select id from accounts where email_encrypted = '%s' and deleted is NULL;", email)
	accountQueryResult := tn.ExecuteSqlCmd(emailQuery)

	if len(strings.Split(accountQueryResult, "\n")) < 2 {
		return 0, errors.New("No account with that email")
	}
	accountId, _ := strconv.Atoi(strings.Split(accountQueryResult, "\n")[1])
	return accountId, nil
}

func AssignPermissions(accountId int, tn *tenant.Tenant, client *ssh.Client, info xymon.XymonSelection, org util.Organization) {
	// Add Authz permissions
	groupsQuery := fmt.Sprintf("select id from authz_groups where organization_id = %d;", org.OrganizationId)
	groupsResult := tn.ExecuteSqlCmd(groupsQuery)
	assignQuery := fmt.Sprintf("insert into authz_groups_accounts (group_id, account_id) values ")
	splitGroups := strings.Split(groupsResult, "\n")[1:]
	splitGroupsLen := len(splitGroups)
	for index, groupId := range splitGroups {
		if groupId == "id" || groupId == "" {
			continue
		}

		if index == splitGroupsLen-2 {
			assignQuery = assignQuery + fmt.Sprintf("(%s, %d)", groupId, accountId)
		} else {
			assignQuery = assignQuery + fmt.Sprintf("(%s, %d), ", groupId, accountId)
		}

	}
	tn.ExecuteSqlCmd(assignQuery + ";")

	// Add Sessionm Admin permissions
	roleId := strings.Split(tn.ExecuteSqlCmd(fmt.Sprintf("select id from roles where service = 'sessionm' and permission = 'write';")), "\n")[1]
	membershipQurey := tn.ExecuteSqlCmd(fmt.Sprintf("select count(*) from account_memberships where account_id = %d;", accountId))
	membershipCount, _ := strconv.Atoi(strings.Split(membershipQurey, "\n")[1])
	if !(membershipCount > 0) {
		insertAccountGroup := fmt.Sprintf("insert into account_groups (organization_id, type) values(%d, 'AccountGroup::Private');", org.OrganizationId)
		tn.ExecuteSqlCmd(insertAccountGroup)

		selectAccountGroup := fmt.Sprintf("select id from account_groups where organization_id = %d and type = 'AccountGroup::Private' order by id desc limit 1;", org.OrganizationId)
		tn.ExecuteSqlCmd(selectAccountGroup)
		accountGroupId := strings.Split(tn.ExecuteSqlCmd(selectAccountGroup), "\n")[1]

		insertAccountGroupRole := fmt.Sprintf("insert into account_group_roles (account_group_id, role_id) values (%s, %s);", accountGroupId, roleId)
		tn.ExecuteSqlCmd(insertAccountGroupRole)

		insertMembership := fmt.Sprintf("insert into account_memberships (account_id, account_group_id) values (%d, %s);", accountId, accountGroupId)
		tn.ExecuteSqlCmd(insertMembership)
	}
}
