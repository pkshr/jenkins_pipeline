package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/xymon"
)

func init() {
	rootCmd.AddCommand(envsCommand)
}

var envsCommand = &cobra.Command{
	Use:   "envs",
	Short: "Gets a list of environments",
	Run: func(cmd *cobra.Command, args []string) {
		xy := xymon.GetXymonData()
		envs := fzf.PrepareXymonData(xy, fzf.PrinterConfig{
			EnvironmentLevel:      true,
			TenantName:            false,
			HostType:              false,
			IpAddr:                false,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		})

		for _, e := range envs {
			fmt.Println(e)
		}
	},
}
