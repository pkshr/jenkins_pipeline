package cmd

import (
	"fmt"
	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/xymon"
)

var (
	sqlStatement = ""
)

func init() {
	rootCmd.AddCommand(execCommand)
	execCommand.Flags().StringVarP(&sqlStatement, "sql", "q", "", "Sql Command for execution on servers")
	execCommand.MarkFlagRequired("sql")
}

var execCommand = &cobra.Command{
	Use:    "exec",
	Short:  "exec commands on servers like xy exec --sql 'select count(*) from ad_campaigns;'",
	Hidden: true,
	Run: func(cmd *cobra.Command, args []string) {
		var fzfCommand string
		if len(first) > 0 {
			fzfCommand = fmt.Sprintf("fzf --no-sort -f '%s'", first)
		} else {
			fzfCommand = "fzf -m -select-1"
		}
		xy := xymon.GetXymonData()
		servers := util.FetchEligibleServers(xy, fzf.PrinterConfig{
			EnvironmentLevel:      true,
			TenantName:            true,
			HostType:              false,
			IpAddr:                false,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		}, fzfCommand)

		newTenant := tenant.Cache()
		for _, tenant := range servers {
			if len(tenant) == 0 {
				continue
			}
			info := fzf.ParseIntoXymonSelection(xy, tenant)

			voltronHost, err := info.VoltronHost()
			if err != nil {
				continue
			}
			client := util.GetSSHClient(info.JumpHost(), voltronHost)

			tn := newTenant(info.EnvironmentLevel, info.TenantName, client)

			util.ExecuteCmd(fmt.Sprintf("mkdir -m 0777 -p /tmp/xy/ && mkdir -m 0777 -p /tmp/xy/%s", info.TenantName), client)

			util.ExecuteCmd(fmt.Sprintf("install -m 666 /dev/null /tmp/xy/%s/sql.xy", info.TenantName), client)
			util.ExecuteCmd(fmt.Sprintf("mysql -B -u %s -p%s -h %s %s -e \" %s \" > /tmp/xy/%s/sql.xy", tn.Database().Production.Username, tn.Database().Production.Password, tn.Database().Production.Host, tn.Database().Production.Database, sqlStatement, info.TenantName), client)
			sqlResult := util.ExecuteCmd(fmt.Sprintf("cat /tmp/xy/%s/sql.xy", info.TenantName), client)
			fmt.Println(fmt.Sprintf("%s, %s", info.TenantName, info.EnvironmentLevel))
			fmt.Println(sqlResult)

			util.ExecuteCmd(fmt.Sprintf("rm /tmp/xy/%s/sql.xy", info.TenantName), client)
		}
	},
}
