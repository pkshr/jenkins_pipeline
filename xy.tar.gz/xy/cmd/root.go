package cmd

// this file is largely taken in whole from Kevin Harrington. Thanks for the original golang implementation.

import (
	"fmt"
	"os"
	"strings"
	"syscall"
	"time"

	"github.com/spf13/cobra"
	"github.com/spf13/viper"
	"gitlab.sessionm.com/xymon/xy/config"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/xymon"
)

var first = ""
var limenvlevel []string
var limtenant []string

func init() {
	vConf, _ := config.ReadXyConfig()

	rootCmd.PersistentFlags().StringP("username", "u", vConf.GetString("username"), "The SSH username you use to access xymon servers")
	rootCmd.PersistentFlags().StringVarP(&first, "first", "f", "", "Skip the fzf fuzzy finder and automatically select the first match of the passed string. E.G: -f 'qa6 ondemand' ")
	rootCmd.PersistentFlags().StringSliceVarP(&limenvlevel, "env-level", "", []string{}, "limit environment level selection to provided value. E.G: --env-level 'ent' or --env-level 'ent_ie,ent' or --env-level 'stg,q'")
	rootCmd.PersistentFlags().StringSliceVarP(&limtenant, "tenant", "", []string{}, "limit tenant to provided value. E.G --tenant 'demo2' or --tenant 'qa4' or --tenant 'qa4,qa3,qa2,qa1' ")
	viper.BindPFlag("username", rootCmd.PersistentFlags().Lookup("username"))
}

var rootCmd = &cobra.Command{
	Use:   "xy",
	Short: "xy is a SessionM utility command for accessing servers",
	Long: `A SessionM utility that will hopefully make your life easier.
~ ❤ Alex G.`,
	Args: cobra.MaximumNArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		var fzfCommand string

		if len(args) > 0 {
			if !util.IsValidIP(args[0]) {
				ip, err := util.FormatIP(args[0])

				if err != nil {
					fmt.Println(err)
					os.Exit(1)
				}
				fzfCommand = fmt.Sprintf("fzf --no-sort -f '%s'", ip)
			} else {
				fzfCommand = fmt.Sprintf("fzf --no-sort -f '%s'", args[0])
			}
		} else if len(first) > 0 {
			fzfCommand = fmt.Sprintf("fzf --no-sort -f '%s'", first)
		} else {
			fzfCommand = "fzf -select-1"
		}

		xy := xymon.GetXymonData()
		servers := util.FetchEligibleServers(xy, fzf.PrinterConfig{
			EnvironmentLevel:      true,
			TenantName:            true,
			HostType:              true,
			IpAddr:                true,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		}, fzfCommand)

		// withFilter returns an array
		info := fzf.ParseIntoXymonSelection(xy, servers[0])

		// make sure ssh key is in agent
		client := util.SSHAgent()
		err := util.EnsureAgentHasKeys(client)

		if err != nil {
			panic(err)
		}

		// log command to .xy.log
		sugar := config.HistoryLogger()
		sugar.Infow(fmt.Sprintf("%s %s %s", info.TenantName, info.EnvironmentLevel, info.HostType),
			"command", "root",
			"ipaddress", info.IpAddr,
			"time", time.Now().Unix(),
			"version", "1",
		)
		sugar.Sync()

		jump := info.JumpHost()

		sshArgs := []string{"ssh", "-o", "StrictHostKeyChecking=no", "-A", "-t", fmt.Sprintf("%s@%s", viper.GetString("username"), jump), "ssh", "-A", fmt.Sprintf("%s@%s", viper.GetString("username"), info.IpAddr)}
		fmt.Println(fmt.Sprintf("%s `#%s %s %s`", strings.Join(sshArgs, " "), info.TenantName, info.EnvironmentLevel, info.HostType))
		env := os.Environ()

		binary := util.SshBinary()
		execErr := syscall.Exec(binary, sshArgs, env)
		if execErr != nil {
			panic(execErr)
		}
	},
}

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}
