package cmd

// import (
//     "fmt"
//     "io"
//     "regexp"
//     "github.com/spf13/cobra"
//     "gitlab.sessionm.com/xymon/xy/util"
//     "gitlab.sessionm.com/xymon/xy/xymon"
// )

// var (
//     trailingOctetsRegexp = regexp.MustCompile(`^\d+\.\d+\.(\d+)\.(\d+)`)
//     format               = "sshconf"
// )

// const (
//     fmtStringDirectConnect = "Host %s\n  HostName %s\n\n"
//     fmtStringProxyOld      = "Host %s\n  HostName %s\n  ProxyCommand ssh %s netcat -w 120 %%h %%p\n\n"
//     fmtStringProxyNew      = "Host %s\n  HostName %s\n  ProxyJump %s\n\n"
// )

// func init() {
//     rootCmd.AddCommand(listCmd)
//     listCmd.Flags().StringVarP(&Source, "source", "s", "sshconf", "Source directory to read from")
// }

// var listCmd = &cobra.Command{
//     Use:   "list",
//     Short: "list tenants, IP's, enironments and host types in whatever format you'd like",
//     Long:  `List allows you to print out information from xymon in a fairly dymanic fashion.
// Want to list out xymon information and pipe it into your ssh
//     `,
//     Run: func(cmd *cobra.Command, args []string) {
//         voltron := map[string]string{}

//         data := xymon.GetXymonData()

//         for fullEnvName, envData := range data {
//             for tenantName, tenantData := range envData {
//                 for hostType, ipAddrs := range tenantData {
//                     for _, ipAddr := range ipAddrs {

//                     trailingIPDigits := trailingOctetsRegexp.ReplaceAllString(ipAddr, "${1}-${2}")
//                     hostAlias := fmt.Sprintf("%s-%s-%s",
//                         envName,
//                         tenantName,
//                         hostType,
//                     )
//                     if hostType == "voltron" {
//                         voltron[fullEnvName] = ipAddrs[0]
//                     }
//                 }
//                 fmt.Fprintln(in, fmt.Sprintf("%s\t%s", fullEnvName, tenantName))
//             }
//         }
//     },
// }
