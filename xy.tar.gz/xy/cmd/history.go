package cmd

import (
	"fmt"
	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/config"
)

func init() {
	rootCmd.AddCommand(historyCmd)
}

var historyCmd = &cobra.Command{
	Use:   "history",
	Short: "Show the xy box history that you've been on",
	Long: `Every time you ssh to a box, xy will store the IP address that you visited.
When you run the command, you'll see the history of IP addresses that you visited
		`,
	Run: func(cmd *cobra.Command, args []string) {
		err := config.ReadHistory()
		if err != nil {
			fmt.Println("There is no history")
		}

	},
}
