package cmd

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/config"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/xymon"
	"io"
	"os"
	"strconv"
	"strings"
	"text/tabwriter"
)

var (
	exportFormat   = ""
	platform       = ""
	apiKey         = ""
	customFileName = ""
)

func init() {
	config.ReadXyConfig()

	rootCmd.AddCommand(authCmd)
	authCmd.Flags().StringVarP(&exportFormat, "export-format", "e", "", "export format for authorization. Defaults to none.")
	authCmd.Flags().StringVarP(&platform, "platform", "p", "", "filter by application platform.")
	authCmd.Flags().StringVarP(&apiKey, "api-key", "k", "", "filter by api_key.")
	authCmd.Flags().BoolP("write-to-file", "w", false, "write to file")
	authCmd.Flags().StringVarP(&customFileName, "filename", "n", "", "custom file name to write to")
}

type Organization struct {
	OrganizationId      int
	OrganizationName    string
	ApplicationName     string
	ApplicationPlatform string
	Appkey              string
	Secret              string
	RewardsSystemId     int
}

type PostmanKeyValue struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

type PostmanEnvironment struct {
	Name   string            `json:"name"`
	Values []PostmanKeyValue `json:"values"`
}

type AuthJson struct {
	OrganizationId      int    `json:"organization_id"`
	OrganizationName    string `json:"organization_name"`
	ApplicationName     string `json:"application_name"`
	ApplicationPlatform string `json:"application_platform"`
	Appkey              string `json:"appkey"`
	Secret              string `json:"secret"`
	RewardsSystemId     int    `json:"rewards_system_id"`
	EnvironmentLevel    string `json:"environment_level"`
	TenantName          string `json:"tenant_name"`
	Domain              string `json:"domain"`
}

var authCmd = &cobra.Command{
	Use:   "auth",
	Short: "Auth api key and secret for xy client",
	Long: `Auth all api keys and secret for an environment level and tenant.
By default, the command ignores applications that are not live and that are mmc api clients.
		`,
	Run: func(cmd *cobra.Command, args []string) {
		if len(exportFormat) > 0 {
			switch exportFormat {
			case "postman", "json":
				break
			default:
				panic(fmt.Errorf("Invalid export format: %s", exportFormat))
			}
		}

		var fzfCommand string
		if len(first) > 0 {
			fzfCommand = fmt.Sprintf("fzf --no-sort -f '%s'", first)
		} else {
			fzfCommand = "fzf -m -select-1"
		}

		xy := xymon.GetXymonData()
		servers := util.FetchEligibleServers(xy, fzf.PrinterConfig{
			EnvironmentLevel:      true,
			TenantName:            true,
			HostType:              false,
			IpAddr:                false,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		}, fzfCommand)

		newTenant := tenant.Cache()
		writeToFile := cmd.Flag("write-to-file").Value.String()
		for _, tenant := range servers {
			if len(tenant) == 0 {
				continue
			}
			info := fzf.ParseIntoXymonSelection(xy, tenant)

			voltronHost, err := info.VoltronHost()
			if err != nil {
				continue
			}
			client := util.GetSSHClient(info.JumpHost(), voltronHost)

			tn := newTenant(info.EnvironmentLevel, info.TenantName, client)
			util.ExecuteCmd(fmt.Sprintf("mkdir -m 0777 -p /tmp/xy/ && mkdir -m 0777 -p /tmp/xy/%s", info.TenantName), client)

			var sqlstatement bytes.Buffer

			// since we're running mysql queries directly via exec through ssh and no known valid values contain quotes, tabs, or newlines,
			// it seems prudent to strip quotes and backslashes in quoted strings altogether to avoid issues w/shell escaping & SQL injection
			repl := strings.NewReplacer("'", "", `"`, "", "\\", "")

			sqlstatement.WriteString("select o.id, o.name, a.name, a.platform, a.api_key, a.secret, d.rewards_system_id from applications a inner join developers d on d.id = a.developer_id inner join organizations o on o.developer_id = d.id where a.mode = 'live'")

			if len(apiKey) > 0 {
				sqlstatement.WriteString(fmt.Sprintf(" and a.api_key = '%s';", repl.Replace(apiKey)))
			}

			if len(platform) > 0 {
				sqlstatement.WriteString(fmt.Sprintf(" and a.platform = '%s';", repl.Replace(platform)))
			} else {
				sqlstatement.WriteString(" and a.platform != 'mmc_api_client';")
			}

			util.ExecuteCmd(fmt.Sprintf("install -m 666 /dev/null /tmp/xy/%s/auth.xy", info.TenantName), client)
			util.ExecuteCmd(fmt.Sprintf("mysql -B -u %s -p%s -h %s %s -e \" %s \" > /tmp/xy/%s/auth.xy", tn.Database().Production.Username, tn.Database().Production.Password, tn.Database().Production.Host, tn.Database().Production.Database, sqlstatement.String(), info.TenantName), client)
			apiCredentials := util.ExecuteCmd(fmt.Sprintf("cat /tmp/xy/%s/auth.xy", info.TenantName), client)
			if len(exportFormat) > 0 {

				apiSelections := util.WithFilter(fzfCommand, func(in io.WriteCloser) {
					apiCredentialsSlice := strings.Split(apiCredentials, "\n")
					for index, credentials := range apiCredentialsSlice {
						if index != 0 {
							fmt.Fprintln(in, credentials)
						}
					}
				})

				for _, apiSelection := range apiSelections {
					if len(apiSelection) == 0 {
						continue
					}
					environmentData := parseSqlResult(apiSelection)
					vConf, _ := config.ReadXyConfig()
					outputName := fmt.Sprintf("%s-%s-%s-%s-%s", info.EnvironmentLevel, info.TenantName, environmentData.OrganizationName, environmentData.ApplicationPlatform, environmentData.ApplicationName)

					var fileName string
					if len(customFileName) > 0 {
						fileName = customFileName
					} else {
						fileName = outputName
					}
					fileName = fmt.Sprintf("%s.json", fileName)

					filePath := fmt.Sprintf("%s/%s - %s", vConf.GetString("postman_export_path"), info.TenantName, info.EnvironmentLevel)
					baseConfig, _ := tn.GetBaseConfig()
					rewardsSystems := baseConfig.RewardsSystemsByID
					rs := rewardsSystems[environmentData.RewardsSystemId]
					var jsonOutput []byte

					if exportFormat == "postman" {

						postmanEnv := PostmanEnvironment{
							Name: outputName,
						}

						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "organization_id", Value: strconv.Itoa(environmentData.OrganizationId)})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "organization_name", Value: environmentData.OrganizationName})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "application_name", Value: environmentData.ApplicationName})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "application_platform", Value: environmentData.ApplicationPlatform})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "appkey", Value: environmentData.Appkey})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "secret", Value: environmentData.Secret})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "rewards_system_id", Value: strconv.Itoa(environmentData.RewardsSystemId)})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "environment_level", Value: info.EnvironmentLevel})
						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "tenant_name", Value: info.TenantName})

						postmanEnv.Values = append(postmanEnv.Values, PostmanKeyValue{Key: "domain", Value: rs.CoreUrl(info.TenantName)})

						jsonOutput, _ = json.Marshal(postmanEnv)
					} else if exportFormat == "json" {
						authJson := AuthJson{
							environmentData.OrganizationId,
							environmentData.OrganizationName,
							environmentData.ApplicationName,
							environmentData.ApplicationPlatform,
							environmentData.Appkey, environmentData.Secret,
							environmentData.RewardsSystemId,
							info.EnvironmentLevel,
							info.TenantName,
							rs.CoreUrl(info.TenantName)}
						jsonOutput, _ = json.Marshal(authJson)
					}

					if writeToFile == "true" {
						err := config.EnsurePathExists(filePath)
						if err != nil {
							fmt.Println(fmt.Errorf("Could not create filepath %s; failed with error: %s", filePath, err))
						}
						filePathAndName := fmt.Sprintf("%s/%s", filePath, fileName)
						f, err := os.OpenFile(filePathAndName, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0666)
						defer f.Close()
						if err != nil {
							fmt.Println(err.Error())
						}
						f.Write(jsonOutput)
						fmt.Printf("Wrote file to: %s \n", filePathAndName)
					} else {
						fmt.Printf("%s", string(jsonOutput))
					}
				}

			} else {
				w := &tabwriter.Writer{}
				w.Init(os.Stdout, 0, 8, 2, '\t', 0)
				fmt.Fprintln(w, apiCredentials)
				w.Flush()
			}
			util.ExecuteCmd(fmt.Sprintf("rm /tmp/xy/%s/auth.xy", info.TenantName), client)
		}
	},
}

func parseSqlResult(tabDelimitedResult string) util.Organization {
	attrs := strings.Split(tabDelimitedResult, "\t")
	organization_id, _ := strconv.Atoi(attrs[0])
	rewards_system_id, _ := strconv.Atoi(attrs[6])

	return util.Organization{
		organization_id,
		attrs[1],
		attrs[2],
		attrs[3],
		attrs[4],
		attrs[5],
		rewards_system_id,
	}
}
