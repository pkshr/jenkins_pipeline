package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/xymon"
)

func init() {
	rootCmd.AddCommand(tenantsCommand)
}

var tenantsCommand = &cobra.Command{
	Use:   "tenants",
	Short: "Gets a list of tenants",
	Run: func(cmd *cobra.Command, args []string) {
		xy := xymon.GetXymonData()
		tenants := fzf.PrepareXymonData(xy, fzf.PrinterConfig{
			EnvironmentLevel:      false,
			TenantName:            true,
			HostType:              false,
			IpAddr:                false,
			LimitTenant:           limtenant,
			LimitEnvironmentLevel: limenvlevel,
		})

		for _, t := range tenants {
			fmt.Println(t)
		}
	},
}
