package verification

import (
    "crypto/tls"
    "net/http"
    "time"
)

func CreateClient() (http.Client) {
    client := http.Client{
        Timeout: time.Duration(3 * time.Second),
        Transport: &http.Transport{
            TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
        },
    }
    return client
}
