package verification

import (
	"fmt"
	consul "github.com/hashicorp/consul/api"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
)

func ConsulCheck(service string, details string, serviceID string, tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) (Service, error) {
	consulService := Service{
		Name:    service,
		Details: details,
	}
	// get the initialized consul client url
	client := tn.ConsulClient()

	// tell the client we want the portion of the API regarding the catalog
	catalog := client.Catalog()

	services, _, err := catalog.Service(serviceID, "", &consul.QueryOptions{})

	if err != nil {
		consulService.SetStatus(0)
		return consulService, err
		// don't panic, the service just isn't configured
	}

	var catalogService *consul.CatalogService

	// we need to check both dedicated and economy because some services are each.
	// E.G, shake shack is in economy, but the tag in consul will not be tenant=shake-shack, it will be tenant=economy.
	// this contrasts with a dedicated env where tenant=qa4 or tenant=starbucks
	economyTag := fmt.Sprintf("tenant=%s", tn.TenantName)
	dedicatedTag := fmt.Sprintf("tenant=%s", rs.TenantUrlName(org.OrganizationName))

	for _, service := range services {
		for _, serviceTag := range service.ServiceTags {
			if serviceTag == dedicatedTag || serviceTag == economyTag {
				catalogService = service
				break
			}
		}
	}
	// test if timeline got set to the initialized version of the struct, not the clean struct
	if catalogService != nil && catalogService.ID != "" {
		consulService.SetStatus(1)
	} else {
		consulService.SetStatus(0)
	}
	return consulService, nil
}
