package services

import (
    "fmt"
    "gitlab.sessionm.com/xymon/xy/tenant"
    "gitlab.sessionm.com/xymon/xy/util"
    "gitlab.sessionm.com/xymon/xy/verification"
)

var (
    timelineConsumerConsulName   = "Timeline Consumer Service"
    timelineEnrichmentConsulName = "Timeline Enrichment Service"
    timelineHealthdConsulName    = "Timeline Healthd"
    timelineRestConsulName       = "Timeline Rest Services"

    timelineConsumerDetails   = "Used for populating Event Stream data"
    timelineEnrichmentDetails = "Consumes messages published by Syslog-NG and then standardizes data via data lookups and publishes messages for the TimeLine Consumer"
    timelineHealthdDetails    = "Checks on status of Timeline APIs"
    timelineRestService       = "API Access to TimeLine Data after enrichment"

    timelineConsumerConsulID   = "timeline-consumer-service"
    timelineEnrichmentConsulID = "timeline-enrichment-service"
    timelineHealthdConsulID    = "timeline-healthd"
    timelineRestConsulID       = "timeline-rest-services"
)

func init() {
    verification.RegisterService(TimelineConsumerServiceCheck)
    verification.RegisterService(TimelineEnrichmentServiceCheck)
    verification.RegisterService(TimelineHealthdServiceCheck)
    verification.RegisterService(TimelineRestServiceCheck)
}

// check that consul has timeline consumer service and rewards system/organization data is configured to enable event stream
func TimelineConsumerServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    timelineConsumerService, _ := verification.ConsulCheck(timelineConsumerConsulName, timelineConsumerDetails, timelineConsumerConsulID, tn, org, rs)

    timelineRSFeature := verification.FeatureCheck{
        Name:    "Rewards System Setting Configured",
        Details: "/enable_event_stream set to true in rewards system",
    }

    timelineOrgFeature := verification.FeatureCheck{
        Name:    "Organization Setting Configured",
        Details: "/event_stream_enabled set to true in organization",
    }

    timelineConsumerService.FeatureChecks = append(timelineConsumerService.FeatureChecks, &timelineRSFeature, &timelineOrgFeature)

    rewardsSystemSql := tn.ExecuteSqlCmd(fmt.Sprintf("SELECT count(*) FROM rewards_systems WHERE rewards_systems.id = %d AND (features LIKE '%%enable_event_stream: true%%')", org.RewardsSystemId))

    // check that rewards system id has event stream enabled
    if tn.SqlNumberResult(rewardsSystemSql) != "0" {
        timelineRSFeature.SetStatus(1)
    } else {
        timelineRSFeature.SetStatus(0)
    }

    organizationSql := tn.ExecuteSqlCmd(fmt.Sprintf("SELECT count(*) FROM organizations WHERE organizations.id = %d AND (data LIKE '%%event_stream_enabled: true%%')", org.OrganizationId))

    // check that organization has event stream enabled
    if tn.SqlNumberResult(organizationSql) != "0" {
        timelineOrgFeature.SetStatus(1)
    } else {
        timelineOrgFeature.SetStatus(0)
    }
    return &timelineConsumerService
}

// check that consul has timeline enrichment service
func TimelineEnrichmentServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    timelineEnrichmentService, _ := verification.ConsulCheck(timelineEnrichmentConsulName, timelineEnrichmentDetails, timelineEnrichmentConsulID, tn, org, rs)
    return &timelineEnrichmentService
}

// check that consul has timeline healthd service
func TimelineHealthdServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    timelineHealthdService, _ := verification.ConsulCheck(timelineHealthdConsulName, timelineHealthdDetails, timelineHealthdConsulID, tn, org, rs)
    return &timelineHealthdService
}

// check that consul has timeline rest service
func TimelineRestServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    timelineRestService, _ := verification.ConsulCheck(timelineRestConsulName, timelineRestService, timelineRestConsulID, tn, org, rs)
    return &timelineRestService
}
