package services

import (
	"encoding/json"
	"fmt"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/verification"
	"io/ioutil"
	"net/http"
)

type HealthCheck struct {
	MySQLConnection struct {
		Status string `json:"status"`
	} `json:"mysql_connection"`
	MemcacheConnection struct {
		Status string `json:"status"`
	} `json:"memcache_connection"`
	CassandraConnection struct {
		Status string `json:"status"`
	} `json:"cassandra_connection"`
}

func init() {
	verification.RegisterService(CoreServiceCheck)
}

func updateFeatureStatus(feature *verification.FeatureCheck, status string) {
	if status == "ok" {
		feature.SetStatus(1)
	} else {
		feature.SetStatus(0)
	}
}

func CoreServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
	coreService := verification.Service{
		Name:               "Core",
		Details:            "Used for core APIs",
		ServiceCheckStatus: 0,
	}

	mclient := verification.CreateClient()

	coreURL := rs.CoreUrl(org.OrganizationName)
	res, err := mclient.Get(coreURL)

	// check that pinging the core url returns a 200
	if err != nil || res.StatusCode != http.StatusOK {
		return &coreService
	}

	healthCheckURL := fmt.Sprintf("%s/health_check", coreURL)
	res, err = mclient.Get(healthCheckURL)

	if err != nil || res.StatusCode != http.StatusOK {
		return &coreService
	}

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return &coreService
	}

	var healthCheck HealthCheck
	err = json.Unmarshal(body, &healthCheck)

	if err != nil {
		return &coreService
	}

	coreMysqlFeature := verification.FeatureCheck{
		Name:    "MySQL connection",
		Details: "/MySQL connection is verified",
	}

	coreMemcacheFeature := verification.FeatureCheck{
		Name:    "Memcache",
		Details: "/Memcache is verified",
	}

	coreCassandraFeature := verification.FeatureCheck{
		Name:    "Cassandra connection",
		Details: "/Cassandra connection is verified",
	}

	coreApplicationsFeature := verification.FeatureCheck{
		Name:    "Applications available",
		Details: "/Applications available besides QA Test",
	}

	coreWhiteLabelAppFeature := verification.FeatureCheck{
		Name:    "White Label Configured",
		Details: "/White label is true in system.yml",
	}

	coreService.FeatureChecks = append(coreService.FeatureChecks, &coreMysqlFeature, &coreMemcacheFeature, &coreCassandraFeature, &coreApplicationsFeature, &coreWhiteLabelAppFeature)

	updateFeatureStatus(&coreMysqlFeature, healthCheck.MySQLConnection.Status)
	updateFeatureStatus(&coreMemcacheFeature, healthCheck.MemcacheConnection.Status)
	updateFeatureStatus(&coreCassandraFeature, healthCheck.CassandraConnection.Status)

	liveApplicationsSql := tn.ExecuteSqlCmd(fmt.Sprintf("select count(*) from applications inner join developers d on applications.developer_id = d.id inner join organizations o on d.id = o.developer_id and o.id = %d AND applications.name NOT LIKE 'QA %%'", org.OrganizationId))
	appCount := tn.SqlNumberResult(liveApplicationsSql)

	if appCount != "0" {
		coreApplicationsFeature.SetStatus(1)
	} else {
		coreApplicationsFeature.SetStatus(0)
	}

	baseConfig, _ := tn.GetBaseConfig()

	if baseConfig.WhiteLabelApp {
		coreWhiteLabelAppFeature.SetStatus(1)
	} else {
		coreWhiteLabelAppFeature.SetStatus(0)
	}

	coreService.SetStatus(1)

	return &coreService
}
