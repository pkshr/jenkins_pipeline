package services

import (
	"fmt"
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
	"gitlab.sessionm.com/xymon/xy/verification"
)

func init() {
	verification.RegisterService(MarmotServiceCheck)
}

func MarmotServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
	marmotService, err := verification.ConsulCheck("Marmot", "Used for Campaigns and Customers reporting", "report-gw", tn, org, rs)

	if err != nil {
		return &marmotService
	}

	marmotFeature := verification.FeatureCheck{
		Name:    "Admin Page Configured",
		Details: "/admin route checks that marmot is hosted correctly",
	}

	marmotService.FeatureChecks = append(marmotService.FeatureChecks, &marmotFeature)

	mclient := verification.CreateClient()
	_, err = mclient.Get(fmt.Sprintf("https://report-gw.%s.%s.local/admin", tn.TenantName, tn.EnvironmentDnsLevel()))

	if err != nil {
		marmotFeature.SetStatus(0)
	} else {
		marmotFeature.SetStatus(1)
	}

	return &marmotService
}
