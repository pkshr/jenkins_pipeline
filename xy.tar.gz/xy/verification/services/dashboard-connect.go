package services

import (
    "fmt"
    "gitlab.sessionm.com/xymon/xy/tenant"
    "gitlab.sessionm.com/xymon/xy/util"
    "gitlab.sessionm.com/xymon/xy/verification"
    "io/ioutil"
    "strings"
)

func init() {
    verification.RegisterService(DashboardConnectServiceCheck)
}

func DashboardConnectServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    dashboardConnectService := verification.Service{
        Name:    "Dashboard Connect",
        Details: "Used for integration with Connect stack",
    }

    orgData := tn.ExecuteSqlCmd(fmt.Sprintf("SELECT data FROM organizations WHERE organizations.id = %d", org.OrganizationId))
    orgDataSqlArr := strings.Split(orgData, "\n")
    orgData = orgDataSqlArr[1]
    orgDataArr := strings.Split(orgData, `\n`)
    var dashboardURL string
    var retailerID string

    for _, key := range orgDataArr {
        if strings.Contains(key, "dashboard_url") {
            dashboardURL = strings.Split(key, ": ")[1]
        } else if strings.Contains(key, "retailer_id") {
            retailerID = strings.Split(key, ": ")[1]
        }
    }

    if dashboardURL == "" || retailerID == "" {
        dashboardConnectService.SetStatus(2)
        return &dashboardConnectService
    }

    mclient := verification.CreateClient()

    var dashboardConnectURL string
    if dashboardURL[len(dashboardURL)-1:] == "/" {
        dashboardConnectURL = strings.Join([]string{dashboardURL, retailerID}, "")
    } else {
        dashboardConnectURL = strings.Join([]string{dashboardURL, retailerID}, "/")
    }

    res, err := mclient.Get(dashboardConnectURL)

    if res == nil {
        dashboardConnectService.SetStatus(0)
        return &dashboardConnectService
    }

    defer res.Body.Close()
    html, _ := ioutil.ReadAll(res.Body)

    // check that pinging the dashboard connect url returns a 200
    if err != nil || res.StatusCode != 200 {
        dashboardConnectService.SetStatus(0)
        return &dashboardConnectService
        // response will return 200 even if retailer id is invalid, so check that the html contains an error message
    } else if strings.Contains(fmt.Sprintf("%s\n", html), "[404]") {
        dashboardConnectService.SetStatus(0)
        return &dashboardConnectService
    } else {
        dashboardConnectService.SetStatus(1)
    }

    return &dashboardConnectService
}
