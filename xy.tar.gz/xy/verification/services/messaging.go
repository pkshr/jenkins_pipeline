package services

import (
    "fmt"
    "github.com/pkg/errors"
    "gitlab.sessionm.com/xymon/xy/tenant"
    "gitlab.sessionm.com/xymon/xy/util"
    "gitlab.sessionm.com/xymon/xy/verification"
    "net/http"
)

func init() {
    verification.RegisterService(MessagingServiceCheck)
}

func RequestProvider(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) (int, error) {
    var statusCode int
    var err error
    baseConfig, _ := tn.GetBaseConfig()

    if _, ok := baseConfig.Services["messaging"]; !ok {
        return statusCode, errors.Wrap(err, "system.yml has no messaging service configured")
    }

    serviceURL := baseConfig.Services["messaging"].URL

    providerRoute := fmt.Sprintf("%s/priv/v1/apps/%s/message/provider", serviceURL, org.Appkey)

    client := verification.CreateClient()
    req, err := http.NewRequest("GET", providerRoute, nil)

    if err != nil {
        return statusCode, err
    }
    req.SetBasicAuth(org.Appkey, org.Secret)
    req.Header.Set("Content-Type", "application/json")

    resp, err := client.Do(req)
    if err != nil {
        return statusCode, err
    }
    statusCode = resp.StatusCode

    defer resp.Body.Close()
    return statusCode, err
}

func MessagingServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    messagingService, _ := verification.ConsulCheck("Messaging APID", "Messaging platform APID service", "messaging-apid", tn, org, rs)

    messagingProviderFeature := verification.FeatureCheck{
        Name:    "Messaging Provider",
        Details: "/Check that API call to get messaging provider responds with a 200 OK",
    }

    messagingService.FeatureChecks = append(messagingService.FeatureChecks, &messagingProviderFeature)
    statusCode, err := RequestProvider(tn, org, rs)

    // check that pinging the provider api route returns a 200
    if err != nil || statusCode != http.StatusOK {
        messagingProviderFeature.SetStatus(0)
    } else {
        messagingProviderFeature.SetStatus(1)
    }

    return &messagingService
}
