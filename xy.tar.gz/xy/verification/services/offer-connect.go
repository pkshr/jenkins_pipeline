package services

import (
    "bytes"
    "crypto/rand"
    "encoding/json"
    "fmt"
    "gitlab.sessionm.com/xymon/xy/tenant"
    "gitlab.sessionm.com/xymon/xy/util"
    "gitlab.sessionm.com/xymon/xy/verification"
    yaml "gopkg.in/yaml.v2"
    "net/http"
    "strings"
)

type Payload struct {
    RetailerID string `json:"retailer_id"`
    UserID     string `json:"user_id"`
}

type AuthTokenServiceData struct {
    OffersAuth struct {
        Key        string   `yaml:"key"`
        RetailerID string   `yaml:"retailer_id"`
        Secret     string   `yaml:"secret"`
        Stores     []string `yaml:"stores"`
    } `yaml:"loyaltree_oauth_v2"`
}

func init() {
    verification.RegisterService(OfferConnectServiceCheck)
}

func pseudoUUID() (uuid string) {

    b := make([]byte, 16)
    _, err := rand.Read(b)
    if err != nil {
        fmt.Println("Error: ", err)
        return
    }

    uuid = fmt.Sprintf("%X-%X-%X-%X-%X", b[0:4], b[4:6], b[6:8], b[8:10], b[10:])

    return
}

func RequestOffer(data *Payload, org *util.Organization, rs *tenant.Rs) (int, error) {
    var statusCode int
    payloadBytes, err := json.Marshal(data)
    if err != nil {
        return statusCode, err
    }
    body := bytes.NewReader(payloadBytes)

    req, err := http.NewRequest("POST", fmt.Sprintf("%s/priv/v1/apps/%s/proxy/offers/api/1.0/offers/get_user_offers", rs.CoreUrl(org.OrganizationName), org.Appkey), body)

    if err != nil {
        return statusCode, err
    }
    req.SetBasicAuth(org.Appkey, org.Secret)
    req.Header.Set("Content-Type", "application/json")

    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return statusCode, err
    }
    statusCode = resp.StatusCode

    defer resp.Body.Close()
    return statusCode, err
}

func OfferConnectServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    offerConnectService := verification.Service{
        Name:               "Offer Connect",
        Details:            "Used for integration with Connect offers",
        ServiceCheckStatus: 2, // Not Configured
    }

    baseURLData := tn.ExecuteSqlCmd(fmt.Sprintf("SELECT base_url FROM user_proxy_destinations WHERE user_proxy_destinations.organization_id = %d AND user_proxy_destinations.destination = '%s'", org.OrganizationId, "offers"))

    var baseURL string
    if baseURLData == "" {
        return &offerConnectService
    }

    baseURLSQLArr := strings.Split(baseURLData, "\n")
    if len(baseURLSQLArr) <= 1 {
        return &offerConnectService
    }
    baseURL = baseURLSQLArr[1]

    if baseURL == "" {
        return &offerConnectService
    }

    authData := tn.ExecuteSqlCmd(fmt.Sprintf("SELECT auth_token_service_data FROM organizations WHERE organizations.id = %d", org.OrganizationId))

    if authData == "" {
        return &offerConnectService
    }

    authDataSQLArr := strings.Split(authData, "\n")

    if len(authDataSQLArr) <= 1 {
        return &offerConnectService
    }

    authTokenServiceDataYml := strings.Replace(authDataSQLArr[1], "\\n", "\n", -1)

    var authInfo AuthTokenServiceData

    err := yaml.Unmarshal([]byte(authTokenServiceDataYml), &authInfo)

    if err != nil {
        return &offerConnectService
    }

    offersAuthVals := authInfo.OffersAuth

    if offersAuthVals.Key == "" || offersAuthVals.Secret == "" || offersAuthVals.RetailerID == "" {
        return &offerConnectService
    }

    if len(offersAuthVals.Stores) == 0 {
        return &offerConnectService
    }

    data := Payload{
        RetailerID: offersAuthVals.RetailerID,
        UserID:     pseudoUUID(),
    }

    statusCode, err := RequestOffer(&data, org, rs)
    if err != nil || statusCode != http.StatusOK {
        offerConnectService.SetStatus(0)
        return &offerConnectService
    }

    offerConnectService.SetStatus(1)

    return &offerConnectService
}
