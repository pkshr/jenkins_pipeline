package services

import (
    "fmt"
    "github.com/pkg/errors"
    "gitlab.sessionm.com/xymon/xy/tenant"
    "gitlab.sessionm.com/xymon/xy/util"
    "gitlab.sessionm.com/xymon/xy/verification"
    yaml "gopkg.in/yaml.v2"
    "strings"
)

type OrganizationData struct {
    AudienceExportEnabled         bool     `yaml:":audience_export_enabled"`
    ConfigModules                 []string `yaml:":config_modules"`
    AdvancedCustomerSearchEnabled bool     `yaml:":advanced_customer_search_enabled"`
}

type ConfigData struct {
    Data struct {
        Meerkat struct {
            URL    string `yaml:"url"`
            Access bool   `yaml:"access"`
        } `yaml:"meerkat"`
    } `yaml:"data"`
}

func init() {
    verification.RegisterService(OndemandServiceCheck)
}

func contains(s []string, e string) bool {
    for _, a := range s {
        if a == e {
            return true
        }
    }
    return false
}

func meerkatIsConfigured(tn *tenant.Tenant) (bool, error) {
    var configData ConfigData
    var err error

    systemYML := util.ExecuteCmd(fmt.Sprintf("cat %s", fmt.Sprintf("/product/voltron/%s/data/core/shared/config/system.yml", tn.TenantName)), tn.SshClient)
    if len(systemYML) == 0 {
        return false, errors.Wrap(err, "YML not found")
    }
    err = yaml.Unmarshal([]byte(systemYML), &configData)
    if err != nil {
        return false, err
    }
    return configData.Data.Meerkat.Access && configData.Data.Meerkat.URL != "", nil
}

func OndemandServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    ondemandService := verification.Service{
        Name:    "Ondemand",
        Details: "Used for SMP services",
    }

    mclient := verification.CreateClient()

    if org.OrganizationName == "" {
        return &ondemandService
    }

    res, err := mclient.Get(rs.OndemandUrl(org.OrganizationName))

    // check that pinging the ondemand url returns a 200
    if err != nil || res.StatusCode != 200 {
        return &ondemandService
    } else {
        ondemandService.SetStatus(1)
    }

    orgData := tn.ExecuteSqlCmd(fmt.Sprintf("SELECT data FROM organizations WHERE organizations.id = %d", org.OrganizationId))

    if orgData == "" {
        return &ondemandService
    }

    orgDataSQLArr := strings.Split(orgData, "\n")

    if len(orgDataSQLArr) <= 1 {
        return &ondemandService
    }

    orgDataYml := strings.Replace(orgDataSQLArr[1], "\\n", "\n", -1)

    var organizationData OrganizationData

    err = yaml.Unmarshal([]byte(orgDataYml), &organizationData)

    if err != nil {
        return &ondemandService
    }

    ondemandAudienceExportFeature := verification.FeatureCheck{
        Name:    "Audience Export Configured",
        Details: "/Audience export is set to true in organization data",
    }

    ondemandService.FeatureChecks = append(ondemandService.FeatureChecks, &ondemandAudienceExportFeature)

    if organizationData.AudienceExportEnabled {
        ondemandAudienceExportFeature.SetStatus(1)
    }

    ondemandCustomers2Feature := verification.FeatureCheck{
        Name:    "Customers2 Configured",
        Details: "/Customers2 module is configured",
    }

    ondemandService.FeatureChecks = append(ondemandService.FeatureChecks, &ondemandCustomers2Feature)

    if contains(organizationData.ConfigModules, "customers2") {
        ondemandCustomers2Feature.SetStatus(1)
    }

    ondemandAdvancedSearchFeature := verification.FeatureCheck{
        Name:    "Advanced Search",
        Details: "/Customers2 advanced search is enabled",
    }

    ondemandService.FeatureChecks = append(ondemandService.FeatureChecks, &ondemandAdvancedSearchFeature)

    if organizationData.AdvancedCustomerSearchEnabled {
        ondemandAdvancedSearchFeature.SetStatus(1)
    }

    ondemandMeerkatFeature := verification.FeatureCheck{
        Name:    "Meerkat",
        Details: "/Meerkat is configured",
    }

    ondemandService.FeatureChecks = append(ondemandService.FeatureChecks, &ondemandMeerkatFeature)

    meerkatConfigured, err := meerkatIsConfigured(tn)

    if err == nil && meerkatConfigured {
        ondemandMeerkatFeature.SetStatus(1)
    }

    return &ondemandService
}
