package services

import (
    "fmt"
    "gitlab.sessionm.com/xymon/xy/tenant"
    "gitlab.sessionm.com/xymon/xy/util"
    "gitlab.sessionm.com/xymon/xy/verification"
)

func init() {
    verification.RegisterService(LoginServiceCheck)
}

func LoginServiceCheck(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *verification.Service {
    loginService := verification.Service{
        Name:    "Login",
        Details: "Used for account integration via OAuth",
    }

    loginRSFeature := verification.FeatureCheck{
        Name:    "Rewards Systems Configured",
        Details: "/Rewards systems are configured in login",
    }

    loginSSOFeature := verification.FeatureCheck{
        Name:    "Sso Configured",
        Details: "/OAuth applications exist for the organization",
    }

    loginService.FeatureChecks = append(loginService.FeatureChecks, &loginRSFeature, &loginSSOFeature)

    mclient := verification.CreateClient()

    res, err := mclient.Get(rs.LoginUrl(org.OrganizationName))

    // check that pinging the login url returns a 200
    if err != nil || res.StatusCode != 200 {
        loginService.SetStatus(0)
        return &loginService
    } else {
        loginService.SetStatus(1)
    }

    // check that the login system.yml has rewards system ids and corresponding domain urls
    if tn.LoginRewardsSystemsAndDomainsAreConfigured() {
        loginRSFeature.SetStatus(1)
    } else {
        loginRSFeature.SetStatus(0)
    }

    // check that the organization has any oauth applications
    oauthApplicationsSql := tn.ExecuteSqlCmd(fmt.Sprintf("select count(*) from oauth_applications oa inner join applications a on oa.application_id = a.id inner join developers d on a.developer_id = d.id inner join organizations o on d.id = o.developer_id and o.id = %d;", org.OrganizationId))
    count := tn.SqlNumberResult(oauthApplicationsSql)

    if count != "0" {
        loginSSOFeature.SetStatus(1)
    } else {
        loginSSOFeature.SetStatus(0)
    }

    return &loginService
}
