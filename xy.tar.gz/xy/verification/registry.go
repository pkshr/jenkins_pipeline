package verification

import (
	"gitlab.sessionm.com/xymon/xy/tenant"
	"gitlab.sessionm.com/xymon/xy/util"
)

type ServiceChecker func(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) *Service

type FeatureCheck struct {
	Name               string
	Details            string
	FeatureName        string
	FeatureCheckStatus int
}

type Service struct {
	Name               string
	Details            string
	ServiceCheckStatus int
	FeatureChecks      []*FeatureCheck
}

var (
	ServiceStatus = map[int]string{
		0: "Failed Healthcheck",
		1: "Passed Healthcheck",
		2: "Not Configured",
	}
	FeatureStatus = map[int]string{
		0: "Disabled",
		1: "Enabled",
		2: "Blocked",
	}
	services []ServiceChecker
)

func (serv *Service) GetStatus() string {
	return ServiceStatus[serv.ServiceCheckStatus]
}

func (serv *Service) SetStatus(status int) {
	serv.ServiceCheckStatus = status
}

func (feat *FeatureCheck) GetStatus() string {
	return FeatureStatus[feat.FeatureCheckStatus]
}

func (feat *FeatureCheck) SetStatus(status int) {
	feat.FeatureCheckStatus = status
}

func RegisterService(serviceChecker ServiceChecker) {
	services = append(services, serviceChecker)
}

func CheckServices(tn *tenant.Tenant, org *util.Organization, rs *tenant.Rs) []*Service {
	var serv []*Service
	for _, cker := range services {
		serv = append(serv, cker(tn, org, rs))
	}

	return serv
}
