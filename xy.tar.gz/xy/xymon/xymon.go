package xymon

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"
)

const (
    Jump     = "jump.sessionm.local"
    JumpIe   = Jump
    JumpSg   = Jump
	JumpCa   = Jump
	JumpWest = Jump
	XymonURL = "http://xymon.infra.local/hosts.json"
)

var (
	EnvJumpHosts = map[string]string{
		"ent":      Jump,
		"ent_ca":   Jump,
        "ent_ie":   JumpIe,
        "ent_sg":   JumpSg,
		"ent_west": Jump,
		"q":        Jump,
		"stg":      Jump,
        "stg_ca":   JumpCa,
	}
	VoltronHosts = map[string]string{}
)

type Xymon struct {
	Servers map[string]map[string]map[string][]string
}

type XymonSelection struct {
	Xymon                   //anonymous field
	EnvironmentLevel string `json:"environment_level"` // stg, ent, ent_ie
	TenantName       string `json:"tenant_name"`       // starbucks, qa4, economy
	HostType         string `json:"host_type"`         // core, ondemand, backend
	IpAddr           string `json:"ip_address"`
}

func (x XymonSelection) JumpHost() string {
	var jump = ""
	jump, ok := EnvJumpHosts[x.EnvironmentLevel]

	if !ok {
		jump = Jump
	}
	return jump
}

func (x XymonSelection) VoltronHost() ( string, error ) {
	if host, ok := VoltronHosts[x.EnvironmentLevel]; ok {
		return host, nil
	} else {
		for environmentLevel, envData := range x.Xymon.Servers {
			for _, tenantData := range envData {
				for hostType, ipAddrs := range tenantData {
					if hostType == "voltron" {
						VoltronHosts[environmentLevel] = ipAddrs[0]
					}
				}
			}
		}

		if _, ok := VoltronHosts[x.EnvironmentLevel]; ok {
			return VoltronHosts[x.EnvironmentLevel],nil
		} else {
			return "",fmt.Errorf( "failed to determine voltron host for env:%s", x.EnvironmentLevel )
		}

	}


}

func GetXymonData() Xymon {
	c := &http.Client{
		Timeout: 15 * time.Second,
	}

	xy := Xymon{}

	response, err := c.Get(XymonURL)
	if err != nil {
		fmt.Println(response)
		fmt.Println(err)
		strings.Contains(err.Error(), "no such host")
		panic(err)
	}

	defer response.Body.Close()
	buf, err := ioutil.ReadAll(response.Body)
	if err != nil {
		panic(err)
	}

	var tmp map[string]interface{}
	if err = json.Unmarshal(buf, &tmp); err != nil {
		panic(err)
	}
	envMap := make(map[string]interface{}, len(EnvJumpHosts))
	for env := range EnvJumpHosts {
		envMap[env] = tmp[env]
	}

	tmp2, _ := json.Marshal(envMap)
	if err = json.Unmarshal(tmp2, &xy.Servers); err != nil {
		panic(err)
	}

	return xy
}
