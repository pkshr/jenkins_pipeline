# XY (pronounced zye): A SessionM Productivity Enhancement Tool.

XY is a tool produced to increase productivity at SessionM. It aids in performing common tasks in qa, staging and production environments, like `ssh`-ing to environments, fetching API keys, and logging into the SMP.

XY is distributed as a binary, through a couple different package managers to serve some operating systems. If your operating system isn't listed on the installation instructions, please feel free to [manually download](https://gitlab.sessionm.com/xymon/xy/releases) whichever binary you'd like.

Myself and other have worked hard on XY over the years. It's largely a side-project, so feature development and bug fixes are largely done in whatever free time we can spare. If you'd like to request a feature, or report a bug, please feel free submit it through the [issues page](https://gitlab.sessionm.com/xymon/xy/issues) using the corresponding template. Please perform some due diligence first of making sure there is not an existing issue matching your request.

I hope you enjoy using XY, and I hope it saves you time.

Alex Gordon

# Installing and Updating
## Prerequisites
Before installing XY a couple prerequisites have to be met for XY to be useful.

1. If you haven't yet, you have to [request](https://sessionm.atlassian.net/wiki/spaces/CORP/pages/28541081/Getting+Access+to+Production+Integration+or+QA+Environments) access to production, integration, or qa environments.
2. Please verify SSH is setup and configured properly. You'll need an SSH key specific to you that has been allowed on qa, stg, or production environments. You can verify SSH is configured properly by SSH-ing to the jump host (check your VPN connection if this doesn't work)

```
ssh $(whoami)@jump.sessionm.local
```

## Mac OS
On Mac OS we use [homebrew](https://brew.sh/) to install XY. Please make sure it is installed and configured before proceeding.

### Installing
#### Removing the previous homebrew tap
If you've previously installed XY through the old `stash.o.sessionm.com` tap then you'll want to remove that first. This command is safe to run if you're unsure of your old installation method.

```
brew untap sessionm/tools
```

Now remove the previous version of XY you have installed
```
brew uninstall xy
```

Now you can continue with adding the latest homebrew tap.

#### Adding the new homebrew tap
Tap the SessionM homebrew tools tap.

```
brew tap sessionm/tools git@gitlab.sessionm.com:packages/sessionm-homebrew-tools.git
```

#### Installing through homebrew

Now that we have the SessionM homebrew tap, we can install XY through there.

```
brew install xy
```

to begin, I'd recommend executing the `xy help` command.

### Updating

To update XY, run

```
brew update && brew upgrade xy
```

## Linux

Currently, for linux support, I'd recommend downloading the binary manually from the [releases page](https://gitlab.sessionm.com/xymon/xy/releases).

## Windows

Currently, for windows support, I'd recommend downloading the binary manually from the [releases page](https://gitlab.sessionm.com/xymon/xy/releases), but [chocolatey](https://chocolatey.org/) support is coming soon.


