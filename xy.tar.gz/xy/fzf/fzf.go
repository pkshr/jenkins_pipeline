package fzf

import (
	"strings"

	"gitlab.sessionm.com/xymon/xy/xymon"
)

type PrinterConfig struct {
	EnvironmentLevel      bool
	TenantName            bool
	HostType              bool
	IpAddr                bool
	LimitTenant           []string
	LimitEnvironmentLevel []string
}

func PrepareXymonData(x xymon.Xymon, conf PrinterConfig) []string {
	var res []string
	for envLevel, envData := range x.Servers {
		var s []string
		if len(conf.LimitEnvironmentLevel) > 0 {
			if !contains(conf.LimitEnvironmentLevel, envLevel) {
				continue
			}
		}

		if conf.EnvironmentLevel {
			if !conf.TenantName && !conf.HostType && !conf.IpAddr {
				res = append(res, envLevel)
				continue
			} else {
				s = append(s, envLevel)
			}
		}

		for tenantName, tenantData := range envData {
			if tenantName == "shared" && !conf.HostType && !conf.IpAddr {
				continue
			}

			if conf.TenantName {
				if len(conf.LimitTenant) > 0 {
					if !contains(conf.LimitTenant, tenantName) {
						continue
					}
				}
				if !conf.HostType && !conf.IpAddr {
					res = append(res, strings.Join(append(s, tenantName), "\t"))
					continue
				} else {
					s = append(s, tenantName)
				}
			}
			for hostType, ipAddrs := range tenantData {
				if conf.HostType {
					if !conf.IpAddr {
						res = append(res, strings.Join(append(s, hostType), "\t"))
						continue
					} else {
						s = append(s, hostType)
					}
				}
				for _, ipAddr := range ipAddrs {
					if hostType == "" || strings.HasSuffix(hostType, "-") {
						continue
					}
					res = append(res, strings.Join(append(s, ipAddr), "\t"))
				}

				if conf.HostType {
					s = s[:len(s)-1]
				}
			}
			if conf.TenantName {
				s = s[:len(s)-1]
			}
		}
	}

	return res
}

func ParseIntoXymonSelection(x xymon.Xymon, tabDelimitedResult string) xymon.XymonSelection {
	attrs := strings.Fields(tabDelimitedResult)
	if len(attrs) > 2 {
		selection := xymon.XymonSelection{
			x,
			attrs[0], // envLevel
			attrs[1], // tenantName
			attrs[2], // hostType
			attrs[3], // ipAddr
		}
		return selection
	} else {
		selection := xymon.XymonSelection{
			x,
			attrs[0], // envLevel
			attrs[1], // tenantName
			"voltron",
			"",
		}
		return selection
	}
}

func contains(s []string, e string) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}
