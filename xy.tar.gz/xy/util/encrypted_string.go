package util

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"database/sql"
	"database/sql/driver"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strings"

	"github.com/golang/glog"
)

const separator = "--"

var defaultIV = make([]byte, aes.BlockSize)

// ErrKeyNotSet is returned from some encryption/decryption functions when the
// encryption key wasn't set.
var ErrKeyNotSet = errors.New("encryption key not set")

type encString struct {
	encryptedString sql.NullString
	encryptionKey   []byte
}

// SetKey sets the encryption key.
func (es *encString) SetKey(encryptionKey []byte) {
	es.encryptionKey = encryptionKey
}

// Scan implements the sql.Scanner interface
func (es *encString) Scan(value interface{}) error {
	return es.encryptedString.Scan(value)
}

// Value implements the sql.Valuer interface. It never returns error.
func (es encString) Value() (driver.Value, error) {
	return es.encryptedString.Value()
}

func (es encString) EncryptedString() string {
	return es.encryptedString.String
}

func (es *encString) aesEncryptCFB(iv []byte, plaintext []byte) []byte {
	origLen := len(plaintext)
	// Ruby encryption strips "extra" data, so we pad it back to blocksize
	text := padToBlockSize(plaintext)
	block, err := aes.NewCipher(es.encryptionKey)
	if err != nil {
		fmt.Println(err)
		glog.Errorln("Unable to create AES cipher")
		return nil
	}
	cfb := cipher.NewCFBEncrypter(block, iv)
	cfb.XORKeyStream(text, text)
	// Stripping "extra" data again, for Ruby compatibility
	return text[:origLen]
}

func (es *encString) aesDecryptCFB(iv []byte, ciphertext []byte) []byte {
	origLen := len(ciphertext)
	// Ruby encryption strips "extra" data, so we pad it back to blocksize
	text := padToBlockSize(ciphertext)
	block, err := aes.NewCipher(es.encryptionKey)
	if err != nil {
		glog.Errorln("Unable to create AES cipher")
		return nil
	}
	cfb := cipher.NewCFBDecrypter(block, iv)
	cfb.XORKeyStream(text, text)
	// Stripping "extra" data again, for Ruby compatibility
	return text[:origLen]
}

func (es *encString) aesEncryptECB128(plaintext []byte) []byte {
	// PKCS7-standard padding is used by OpenSSL/Ruby for this, so we're using it too...
	text := padPKCS7(plaintext)
	block, err := aes.NewCipher(es.encryptionKey[:16]) // using a 16 byte key causes 128-bit crypto
	if err != nil {
		glog.Errorln("Unable to create AES cipher")
		return nil
	}
	remaining := text
	for len(remaining) > 0 {
		block.Encrypt(remaining, remaining)
		remaining = remaining[aes.BlockSize:]
	}
	return text
}

func (es *encString) aesDecryptECB128(iv []byte, ciphertext []byte) []byte {
	origLen := len(ciphertext)
	text := padToBlockSize(ciphertext)
	block, err := aes.NewCipher(es.encryptionKey[:16]) // using a 16 byte key causes 128-bit crypto
	if err != nil {
		glog.Errorln("Unable to create AES cipher")
		return nil
	}
	remaining := text
	for len(remaining) > 0 {
		block.Decrypt(remaining, remaining)
		remaining = remaining[aes.BlockSize:]
	}
	// Stripping "extra" data again, for Ruby compatibility
	return text[:origLen]
}

// EncryptedString encrypts to a base64 encoded string when used as
// sql.Valuer. It writes empty string if the inputs is an empty string.
type EncryptedString struct {
	encString
}

// NewEncryptedString returns initialized EncryptedString with its key and value
// set.
func NewEncryptedString(plaintext string, key []byte) (es EncryptedString) {
	es.SetKey(key)
	es.SetValue(plaintext)
	return es
}

// String returns the EncryptedString's Plaintext value as a string
func (es EncryptedString) String() string {
	return string(es.Bytes())
}

// Bytes returns the EncryptedString's Plaintext value as a byte slice
func (es EncryptedString) Bytes() []byte {
	return es.Decrypt(es.encryptedString.String)
}

// SetValue sets the EncryptedString's value via a plaintext string. To set
// EncryptedString's value via an encrypted string, use Scan.
//
// If key is not set, SetValue panics.
func (es *EncryptedString) SetValue(plaintext string) {
	es.encryptedString = sql.NullString{
		String: es.Encrypt(plaintext),
		Valid:  true,
	}
}

// Encrypt returns base64 encoded string containing encrypted message.
func (es EncryptedString) Encrypt(plaintext string) string {
	randomBytes := make([]byte, aes.BlockSize)
	io.ReadFull(rand.Reader, randomBytes)

	var encrypted bytes.Buffer
	encrypted.WriteString(base64.StdEncoding.EncodeToString(es.aesEncryptECB128(randomBytes)))
	encrypted.WriteString(separator)
	encrypted.WriteString(base64.StdEncoding.EncodeToString(es.aesEncryptCFB(randomBytes[:aes.BlockSize], []byte(plaintext))))
	return encrypted.String()
}

// Decrypt returns decrypted message in form of bytes.
func (es EncryptedString) Decrypt(encrypted string) []byte {
	parts := strings.Split(encrypted, separator)
	if len(parts) != 2 {
		return nil
	}
	var ciphertext []byte
	ivEnc, err := base64.StdEncoding.DecodeString(parts[0])
	if err == nil {
		ciphertext, err = base64.StdEncoding.DecodeString(parts[1])
	}
	if err != nil {
		glog.Errorf("Unable to base64 decode string(%v)", encrypted)
		return nil
	}
	iv := es.aesDecryptECB128(defaultIV, ivEnc)
	if len(iv) < aes.BlockSize {
		glog.Errorf("invalid iv (%v)", iv)
		return nil
	}
	return es.aesDecryptCFB(iv[:aes.BlockSize], ciphertext)
}

// MarshalJSON implements json.Marshaler interface. It returns DECRYPTED string.
// It returns ErrKeyNotSet if a key is not set.
func (es EncryptedString) MarshalJSON() ([]byte, error) {
	if len(es.encryptionKey) == 0 {
		return nil, ErrKeyNotSet
	}
	return json.Marshal(es.String())
}

// UnmarshalJSON implements json.Unmarshaler interface. It expects NOT encrypted
// string. It returns ErrKeyNotSet if a key is not set.
func (es *EncryptedString) UnmarshalJSON(data []byte) error {
	if len(es.encryptionKey) == 0 {
		return ErrKeyNotSet
	}
	es.SetValue(strings.Trim(string(data), "\""))
	return nil
}

// NullEncryptedString encrypts to a base64 encoded string when used as
// sql.Valuer. It writes null for empty string instead of an empty string.
type NullEncryptedString struct {
	EncryptedString
}

// NewNullEncryptedString returns initialized EncryptedString with its key and value
// set.
func NewNullEncryptedString(plaintext string, key []byte) (nes NullEncryptedString) {
	nes.SetKey(key)
	nes.SetValue(plaintext)
	return nes
}

// SetValue sets the NullEncryptedString's value via a plaintext string. To set
// EncryptedString's value via an encrypted string, use Scan.
//
// If key is not set, SetValue panics.
func (es *NullEncryptedString) SetValue(plaintext string) {
	if len(plaintext) == 0 {
		es.encryptedString = sql.NullString{}
	} else {
		es.EncryptedString.SetValue(plaintext)
	}
}

// EncryptedUniqueString encrypts to a unique base64 encoded string when used as
// sql.Valuer. It writes empty string if the input is an empty string.
type EncryptedUniqueString struct {
	encString
}

// NewEncryptedUniqueString returns initialized EncryptedUniqueString with its
// key and value set.
func NewEncryptedUniqueString(plaintext string, key []byte) (es EncryptedUniqueString) {
	es.SetKey(key)
	es.SetValue(plaintext)
	return es
}

// Bytes decrypts and returns underlying message and returns it in a form of
// bytes.
func (es EncryptedUniqueString) Bytes() []byte {
	return es.Decrypt(es.encryptedString.String)
}

// String is same as Bytes(), but returns a string.
func (es EncryptedUniqueString) String() string {
	return string(es.Bytes())
}

// SetValue sets the EncryptedString's value via a plaintext string. To set
// EncryptedString's value via an encrypted string, use Scan.
//
// If key is not set, SetValue panics.
func (es *EncryptedUniqueString) SetValue(plaintext string) {
	es.encryptedString = sql.NullString{
		String: es.Encrypt(plaintext),
		Valid:  true,
	}
}

// Encrypt returns base64 encoded string containing encrypted unique message.
func (es EncryptedUniqueString) Encrypt(plaintext string) string {
	encrypted := es.aesEncryptCFB(defaultIV, []byte(plaintext))
	return base64.StdEncoding.EncodeToString(encrypted)
}

// Decrypt returns decrypted unique message in form of bytes.
func (es EncryptedUniqueString) Decrypt(encrypted string) []byte {
	ciphertext, err := base64.StdEncoding.DecodeString(encrypted)
	if err != nil {
		glog.Warningln("Unable to base64 decode string(%v)", encrypted)
		return nil
	}
	return es.aesDecryptCFB(defaultIV, ciphertext)
}

// MarshalJSON implements json.Marshaler interface. It returns DECRYPTED string.
// It returns ErrKeyNotSet if a key is not set.
func (es EncryptedUniqueString) MarshalJSON() ([]byte, error) {
	if len(es.encryptionKey) == 0 {
		return nil, ErrKeyNotSet
	}
	return json.Marshal(es.String())
}

// UnmarshalJSON implements json.Unmarshaler interface. It expects NOT encrypted
// string. It returns ErrKeyNotSet if a key is not set.
func (es *EncryptedUniqueString) UnmarshalJSON(data []byte) error {
	if len(es.encryptionKey) == 0 {
		return ErrKeyNotSet
	}
	es.SetValue(strings.Trim(string(data), "\""))
	return nil
}

// NullEncryptedUniqueString encrypts to a unique base64 encoded string when used as
// sql.Valuer. It writes null for empty string instead of an empty string.
type NullEncryptedUniqueString struct {
	EncryptedUniqueString
}

// NewNullEncryptedUniqueString returns initialized EncryptedUniqueString with its
// key and value set.
func NewNullEncryptedUniqueString(plaintext string, key []byte) (nes NullEncryptedUniqueString) {
	nes.SetKey(key)
	nes.SetValue(plaintext)
	return nes
}

// SetValue sets the EncryptedString's value via a plaintext string. To set
// EncryptedString's value via an encrypted string, use Scan.
//
// If key is not set, SetValue panics.
func (es *NullEncryptedUniqueString) SetValue(plaintext string) {
	es.encryptedString = sql.NullString{
		String: es.Encrypt(plaintext),
		Valid:  len(plaintext) > 0,
	}
}

// EncryptString gives EncryptedString encrypt functionality in one function
// call.
func EncryptString(plaintext string, key []byte) string {
	var es EncryptedString
	es.SetKey(key)
	return es.Encrypt(plaintext)
}

// DecryptString gives EncryptedString decrypt functionality in one function
// call.
func DecryptString(encrypted string, key []byte) []byte {
	var es EncryptedString
	es.SetKey(key)
	return es.Decrypt(encrypted)
}

// EncryptUniqueString gives EncryptedUniqueString encrypt functionality in one
// function call.
func EncryptUniqueString(plaintext string, key []byte) string {
	var es EncryptedUniqueString
	es.SetKey(key)
	return es.Encrypt(plaintext)
}

// DecryptUniqueString gives EncryptedUniqueString decrypt functionality in one
// function call.
func DecryptUniqueString(encrypted string, key []byte) []byte {
	var es EncryptedUniqueString
	es.SetKey(key)
	return es.Decrypt(encrypted)
}

// Setter provides SetKey method and it is intended to be used in SetKeys
// function. EncryptedString and EncryptedUniqueString implement this interface.
type Setter interface {
	SetKey([]byte)
}

// SetKeys sets the given key to all given setters.
func SetKeys(key []byte, setters ...Setter) {
	for _, s := range setters {
		s.SetKey(key)
	}
}

func padPKCS7(b []byte) []byte {
	padCt := aes.BlockSize - (len(b) % aes.BlockSize)
	result := make([]byte, len(b), len(b)+padCt)
	copy(result, b)
	for i := 0; i < padCt; i++ {
		result = append(result, byte(padCt))
	}
	return result
}

func padToBlockSize(b []byte) []byte {
	result := make([]byte, len(b), len(b)+aes.BlockSize)
	copy(result, b)
	for len(result)%aes.BlockSize > 0 {
		result = append(result, 0)
	}
	return result
}
