package util

import (
	"bytes"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"net"
	"os"
	"os/exec"
	"os/user"
	"regexp"
	"runtime"
	"strings"

	"github.com/howeyc/gopass"
	"github.com/spf13/viper"
	"github.com/xanzy/ssh-agent"
	"gitlab.sessionm.com/xymon/xy/config"
	"gitlab.sessionm.com/xymon/xy/fzf"
	"gitlab.sessionm.com/xymon/xy/xymon"
	"golang.org/x/crypto/ssh"
	"golang.org/x/crypto/ssh/agent"
)

const ipRegex string = `^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$`

func SshBinary() string {
	var bin string
	var lookErr error
	if runtime.GOOS == "windows" {
		bin, lookErr = exec.LookPath("ssh.exe")
	} else {
		bin, lookErr = exec.LookPath("ssh")
	}

	if lookErr != nil {
		panic(lookErr)
	}

	return bin
}

// initializes and fetches result from a command
func WithFilter(command string, input func(in io.WriteCloser)) []string {
	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		cmd = exec.Command("cmd", "/C", strings.Replace(command, "fzf", "fzf.exe", 1))
	} else {
		shell := os.Getenv("SHELL")
		if len(shell) == 0 {
			shell = "sh"
		}
		cmd = exec.Command(shell, "-c", command)
	}

	cmd.Stderr = os.Stderr
	in, _ := cmd.StdinPipe()
	go func() {
		input(in)
		in.Close()
	}()
	result, _ := cmd.Output()

	if len(result) == 0 {
		// nothing selected, goodbye
		os.Exit(1)
	}

	return strings.Split(string(result), "\n")
}

// Given xymon data, this looks a current flags and then returns servers based on flag limitation.
// in the event that only one option is available, then that option is automatically selected, and the fuzzy finder is skipped.
func FetchEligibleServers(x xymon.Xymon, conf fzf.PrinterConfig, command string) []string {
	servers := fzf.PrepareXymonData(x, conf)

	if len(servers) == 1 {
		return servers
	} else {
		servers := WithFilter(command, func(in io.WriteCloser) {
			for _, s := range servers {
				fmt.Fprintln(in, s)
			}
		})
		return servers
	}
}

func SshUser() string {
	user, _ := user.Current()
	return user.Username
}

func SSHAuthSock() net.Conn {

	sshAgent, err := net.Dial("unix", os.Getenv("SSH_AUTH_SOCK"))
	if err != nil {
		fmt.Println(fmt.Errorf("Can't get ssh auth socket: %s", err))
		os.Exit(1)
	}

	return sshAgent
}

func SSHAgent() agent.Agent {
	agent, _, err := sshagent.New()
	if err != nil {
		panic(err)
	}
	return agent
}

func SSHAuthMethod() ssh.AuthMethod {
	return ssh.PublicKeysCallback(SSHAgent().Signers)
}

func GetSSHClient(bastion string, destination string) *ssh.Client {
	client := SSHAgent()
	err := EnsureAgentHasKeys(client)
	if err != nil {
		os.Exit(1)
	}

	sshconfig := &ssh.ClientConfig{
		User: viper.GetString("username"),
		Auth: []ssh.AuthMethod{
			ssh.PublicKeysCallback(client.Signers),
		},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
	}
	// fmt.Println("bastion and destination", bastion, destination)

	bastionConn, err := ssh.Dial("tcp", fmt.Sprintf("%s:22", bastion), sshconfig)
	if err != nil {
		panic(fmt.Errorf("Failed to dial: %s", err))
	}

	// Dial a connection to the service host, from the bastion
	hostConn, err := bastionConn.Dial("tcp", fmt.Sprintf("%s:22", destination))
	if err != nil {
		panic(fmt.Errorf("bastion connection error: %s. \n Attempted to connect to jump %s, with ultimate destination %s", err, bastion, destination))
	}
	// fmt.Println(fmt.Sprintf("%s:22", destination))
	ncc, chans, reqs, cerr := ssh.NewClientConn(hostConn, fmt.Sprintf("%s:22", destination), sshconfig)
	if cerr != nil {
		panic(fmt.Errorf("client connection error: %s", cerr))
	}

	sClient := ssh.NewClient(ncc, chans, reqs)

	return sClient
}

// ReadPrivateKey attempts to read a private key at a specified path and add that private key to the ssh agent.
func ReadPrivateKey(rsaPrivateKeyLocation string) (*rsa.PrivateKey, error) {
	if rsaPrivateKeyLocation == "" {
		fmt.Println("No RSA Key given")
	}

	priv, err := ioutil.ReadFile(rsaPrivateKeyLocation)
	if err != nil {
		fmt.Println("No RSA private key found")
	}

	privPem, _ := pem.Decode(priv)
	var privPemBytes []byte
	if privPem.Type != "RSA PRIVATE KEY" {
		fmt.Println("RSA private key is of the wrong type")
	}

	rsaPrivateKeyPassword := []byte(os.Getenv("IDENTITY_PASSPHRASE"))
	if len(rsaPrivateKeyPassword) == 0 {
		fmt.Print("Enter passphrase to unlock private key:")
		rsaPrivateKeyPassword, err = gopass.GetPasswd()
		if err != nil {
			return nil, fmt.Errorf("couldn't read IDENTITY_PASSPHRASE: %v", err)
		}
	}

	privPemBytes, err = x509.DecryptPEMBlock(privPem, []byte(rsaPrivateKeyPassword))

	var parsedKey interface{}
	if parsedKey, err = x509.ParsePKCS1PrivateKey(privPemBytes); err != nil {
		if parsedKey, err = x509.ParsePKCS8PrivateKey(privPemBytes); err != nil { // note this returns type `interface{}`
			fmt.Println("Unable to parse RSA private key, generating a temp one")
		}
	}

	var privateKey *rsa.PrivateKey
	var ok bool
	privateKey, ok = parsedKey.(*rsa.PrivateKey)
	if !ok {
		fmt.Println("Unable to parse RSA private key, generating a temp one")
	}

	return privateKey, nil
}

func EnsureAgentHasKeys(client agent.Agent) error {
	if keys, _ := client.List(); len(keys) == 0 {
		pk, parseerr := ReadPrivateKey(fmt.Sprintf("%s/.ssh/id_rsa", config.HomePath()))
		if parseerr != nil {
			fmt.Println(fmt.Errorf("Unable to parse ssh key. Please unlock local ssh keys manually."))
			return parseerr
		}

		keyadderr := client.Add(agent.AddedKey{PrivateKey: pk})

		if keyadderr != nil {
			fmt.Println(fmt.Errorf("Unable to add ssh key to ssh agent. %s", keyadderr))
			return keyadderr
		}
	}

	return nil
}

func ExecuteCmd(command string, client *ssh.Client) string {
	session, err := client.NewSession()
	if err != nil {
		fmt.Println(fmt.Errorf("Failed to create session: %s", err))
	}

	var stdoutBuf bytes.Buffer
	session.Stdout = &stdoutBuf
	session.Run(command)
	return fmt.Sprintf("%s", stdoutBuf.String())
}

func FormatIP(ip string) (string, error) {
	re := regexp.MustCompile("[A-Za-z_]")
	split := strings.SplitN(strings.TrimPrefix(re.ReplaceAllString(ip, ""), "-"), ".", 2)
	ip = strings.ReplaceAll(split[0], "-", ".")
	if IsValidIP(ip) {
		return ip, nil
	}
	return ip, errors.New("Invalid IP format: " + ip)
}

func IsValidIP(ip string) bool {
	re := regexp.MustCompile(ipRegex)
	if re.MatchString(ip) {
		return true
	}
	return false
}
