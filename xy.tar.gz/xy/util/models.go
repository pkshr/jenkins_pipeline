package util

type Organization struct {
	OrganizationId      int
	OrganizationName    string
	ApplicationName     string
	ApplicationPlatform string
	Appkey              string
	Secret              string
	RewardsSystemId     int
}